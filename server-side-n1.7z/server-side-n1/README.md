# N1 da materia server-side

Esta  avaliação  é individual  e  compõem  40%da N1  (4,0, quatropontos), asolução  de  cada  enunciado  tem  que  ser apresentada in-loco. O objetivo é avaliar o desenvolvimento da lógica de programação na resolução de cada exercício (a à d), assim como a execução eexplicação de cada programa, por meio do framework nodejs.

-----

**a)** um conjunto de leitores respondeu a um survey(pesquisa)que continha as seguintes perguntas: qual a idade de cada  leitor? Em qual  cidade  o leitor mora? E a opinião em  relação ao livro que  fora  lançado meses atrás,  em que o leitor respondeuma das seguintes opções: 3-ótimo, 2 -bom e 1 –regular (1,25).

Escreva um programa que receba a idade, a cidade e a opinião de 16 leitores, calcule e exiba: a média das idades dos leitores que responderam ótimo;a quantidade de leitores que responderam regular;a porcentagem de leitores que responderam bom entre todos os leitores;a porcentagem de leitores para cada cidade.

-----

**b)** Em  uma  certificação  são  feitos  5  exames  (I,  II,  III,  IV  e  V).  Escreva  um  programa  que  leia as  notas  desses exames e imprima a classificação do interessado na certificação, sabendo que a média é 70. Classificação: A –passou em todos os exames; B –passou em I, II e IV, mas não em III ou V; C –passou em I e II, III ou IV, mas não em V. Reprovado –outras situações(1,0).

-----

**c)** Chama-se ano bissexto o ano ao qual é acrescentado um dia extra, ficando ele com 366 dias, um dia a mais do que os anos normais de 365 dias, ocorrendo a cada quatro anos. Escreva um programa que verifique se um ano é  bissexto. Um  ano  é  bissexto  se  ele  é  divisível  por  4.  Entretanto,  se  o  ano  é  divisível  por  100,  ele  não  é bissexto. Mas, se ele for divisível por 400, ele volta a ser bissexto (0,5). 

a.São bissextos os anos: 1600, 1996, 2000, 2004, 2008, 2012, 2016, 2400, 2800, ...  
b.Não são bissextos: 1500, 1974, 1982, 1983, 1990, 2018, 2022, 2030, 2038, ...

-----

**d)** O Hipermercado Tabajara está com uma promoção de carnes que é imperdível. Confira:

|            | Até 5Kg  | Acima de 5Kg |         |
|------------|----------|--------------|---------|
| Filé Duplo | R$ 24,90 | R$ 25,80     | por Kg. |
| Alcatra    | R$ 25,90 | R$ 26,80     | por Kg. |
| Picanha    | R$ 35,90 | R$ 37,80     | por Kg. |

Para  atender  os  clientes,  cada  cliente  poderá  levar  apenas  um  dos  tipos  de  carne  da  promoção, porém  não  há limites para a quantidade de carne por cliente. Se  compra  for  feita  no  cartão  Tabajara  o  cliente  receberá  ainda  um  desconto  de  5%  sobre  o  total  da  compra. Escreva um programa que peça o tipo e a quantidade de carne comprada pelo usuário e gere um cupom fiscal, contendo  as  informações  da  compra:  tipo  e  quantidade  de  carne,  preço  total,  tipo  de  pagamento,  valor  do desconto e valor a pagar (1,25).

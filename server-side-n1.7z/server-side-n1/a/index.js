const prompt = require('prompt-sync')()

class Pessoa{
    constructor(idade, cidade, opiniao){
        this.idade = idade,
        this.cidade = cidade,
        this.opiniao = opiniao
    }
}

let cidades = {}

function criarPessoa(){
    console.log('------------------')

    let idade = parseInt(prompt("Insira sua idade: "))
    let cidade = prompt("Insira sua cidade: ")
    let opiniao = parseInt(prompt("Insira sua avaliacao -> 3=otimo | 2=bom | 1=regular: "))

    if(cidades[cidade]){
        cidades[cidade]++
    }else{
        cidades[cidade] = 1;
    }

    return new Pessoa(idade, cidade, opiniao)
}

let pessoas = [];

for(let i = 0; i < 3; i++){
    pessoas[i] = criarPessoa()
}

function calcularMedia(){
    let total = 0;

    for(let i = 0; i < pessoas.length; i++){
        total = total + pessoas[i].idade
    }

    return (total / pessoas.length)
}

function quantidadeDeRegular(){
    let total = 0;

    for(let i = 0; i < pessoas.length; i++){
        if(pessoas[i].opiniao == 1){
            total = total + 1
        }
    }

    return total;
}

function porcentagemDeBom(){
    let total = 0;

    for(let i = 0; i < pessoas.length; i++){
        if(pessoas[i].opiniao == 2){
            total = total + 1
        } 
    }

    return ((total / pessoas.length) * 100)
}

console.log('\\\\==================//')

console.log('Media das idades = ' + calcularMedia())
console.log('Quantidade que respondeu "Regular" = ' + quantidadeDeRegular())
console.log('Porcentagem que respondeu "Bom" = ' + porcentagemDeBom() + '%')
// FALTA CALCULAR A PORCENTAGEM POR CADA IDADE (usando hashmap)
console.log('Porcentagem por cada idade = ')

console.log()